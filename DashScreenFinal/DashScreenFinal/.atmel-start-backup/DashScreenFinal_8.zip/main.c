#include <atmel_start.h>
#include "DisplayNumbersAndText.h"
#include "SPI_io_descriptor.h"

/*** WHEN CHANGING SCREEN ***/
/*
Go to FT8_config.h and chnage the FT8_Vsize and FT8_Hsize variables at the bottom.
For the 4.2" screen the values should be:
#define FT8_VSIZE     (272L)   Tvd Number of visible lines (in lines) - display height
#define FT8_HSIZE     (480L)   Thd Length of visible part of line (in PCLKs) - display width

For the 5" screen the valuse should be
#define FT8_VSIZE     (480L)   Tvd Number of visible lines (in lines) - display height
#define FT8_HSIZE     (800L)   Thd Length of visible part of line (in PCLKs) - display width

Everything in the code is coded wrt to WIDTH and HEIGH vars which are defined AT THE TOP OF DISPLAYNUMBERSANDTEXT.H and will automatically update the proportions of the screen and font!
*/

int main(void)
{
	
	/* Initializers */
	atmel_start_init();
	create_spi_descriptor();
	FT8_init();
	

	/* Functionality Loop */
	
	while (1) {
		delay_ms(1000); // replace with trigger
		
		// Everything must happen within the Start and End frame placeholders
		startFrame();
		
		// test text functions
		display_text(0.5*WIDTH,HEIGHT*0.5,22,"asdf");
		display_textColor(50,30,22,"blue",0,0,255);
		display_textRight(50,50,22,"fdsa");
		display_textColorRight(50,70,22,"re+gr",255,255,0);

		//test number functions
		display_number(150,10,22,00155);
		display_numberColor(150,30,22,245,0,255,0);
		display_numberRight(150,50,22,22432);
		display_numberColorRight(150,70,22,765432,255,0,0);

		// test text_number functions
		display_text_number(250,10,22,"speed ",120);
		display_text_numberColor(250,30,22,"place: ",2,100,255,100);


		// test gauge
		display_gauge(100,150,70,40,60);
		
		// test progress bar
		//display_progress(200, 150,150,20, 50);
		display_progress(200,100,40,150,30);
		
		
		
		endFrame();
		
		

		
	}
}
