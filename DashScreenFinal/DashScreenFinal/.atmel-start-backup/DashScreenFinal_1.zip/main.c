#include <atmel_start.h>

//#include "MessageLog.h"
#include "DisplayNumbersAndText.h"
#include "SPI_io_descriptor.h"


int main(void)
{
	
	/* INITIALIZATION */
	
	atmel_start_init(); // atmel_start
	create_spi_descriptor(); // spi descriptor (to initialise the SPI communication wiht the graphics card)
	FT8_init(); // initialize the FT8 Graphics Library!
	
	/* Loop Application */
	while (1) {
		delay_ms(1000); // convert to trigger
		
		////////* Each Frame Drawing Happens Between These Bounds */////////
		startFrame();
		
		// test text functions
		display_text(0.5*WIDTH,HEIGHT*0.5,22,"asdf");
		display_textColor(50,30,22,"blue",0,0,255);
		display_textRight(50,50,22,"fdsa");
		display_textColorRight(50,70,22,"re+gr",255,255,0);

		//test number functions
		display_number(150,10,22,00155);
		display_numberColor(150,30,22,245,0,255,0);
		display_numberRight(150,50,22,22432);
		display_numberColorRight(150,70,22,765432,255,0,0);

		// test text_number functions
		display_text_number(250,10,22,"speed ",120);
		display_text_numberColor(250,30,22,"place: ",2,100,255,100);


		// test gauge
		display_gauge(100, 150, 70, 0, 10, 5, 60, 60);
		
		
		endFrame();
		////////* Each Frame Drawing Happens Between These Bounds */////////
		
		

		
	}
}
