#include <atmel_start.h>
#include "DisplayNumbersAndText.h"
#include "SPI_io_descriptor.h"
#include "USER_DEF.h"

int main(void)
{
	
	int framenum = 0;
	
	/* Initializers */
	atmel_start_init();
	create_spi_descriptor();
	FT8_init();
	

	/* Functionality Loop */
	
	while (1) {
		delay_ms(1000); // replace with trigger (but this is delay one second)
		
		// Everything must happen within the Start and End frame placeholders
		startFrame();
		
		/*// test text functions
		display_text(0.5*WIDTH,HEIGHT*0.5,22,"asdf");
		display_textColor(50,30,22,"blue",0,0,255);
		display_textRight(50,50,22,"fdsa");
		display_textColorRight(50,70,22,"re+gr",255,255,0);

		//test number functions
		display_number(150,10,22,00155);
		display_numberColor(150,30,22,245,0,255,0);
		display_numberRight(150,50,22,22432);
		display_numberColorRight(150,70,22,765432,255,0,0);

		//test text_number functions
		display_text_number(250,10,22,"speed ",120);
		display_text_numberColor(250,30,22,"place: ",2,100,255,100);*/


		// SPEEDOMETER
		display_gauge((framenum%gauge_range)); // sPEEDOMETER GAUGE
		display_text((int)(gauge_x0-(gauge_radius*0.7)),10,22,"SPEEDOMETER"); // TITLE
		display_text((int)(gauge_x0-(gauge_radius*0.1)),(int)(HEIGHT-(0.05*HEIGHT)),20,"KM/H"); // UNIT
		
		// SEPARATOR LINE (SECTION, SPEEDOMETER)
		display_line(VERT_X,0, VERT_X, HEIGHT, 3);
		
		// SERPARATOR LINES, RIGHT HAND SIDE SECTIONS
		display_line(VERT_X,(int)(HEIGHT*(0.3333)),WIDTH,(int)(HEIGHT*(0.3333)),3);
		display_line(VERT_X,(int)(HEIGHT*(0.6667)),WIDTH,(int)(HEIGHT*(0.6667)),3);
		
		// BATTERY CHARGE
		display_progress(((framenum*5)%battery_range));
		display_text((int)(VERT_X+(0.05*WIDTH)),10,22,"BATTERY CHARGE"); // TITLE
		
		// BATTERY TEMP
		display_text((int)(VERT_X+(0.05*WIDTH)),(int)((HEIGHT*0.3333)+(0.03*HEIGHT)),22,"BATTERY"); // TITLE
		display_text((int)(VERT_X+(0.05*WIDTH)),(int)((HEIGHT*0.3333)+(0.13*HEIGHT)),22,"TEMP"); // TITLE
		display_text((int)(VERT_X+(0.05*WIDTH)),(int)((HEIGHT*0.3333)+(0.23*HEIGHT)),22,"(degC)"); // TITLE
		// TO SET A FONT HIGHER THAN 31:
		FT8_cmd_romfont(1,33);
		display_numberRight((int)(WIDTH-(0.03*WIDTH)),(int)((HEIGHT*0.3333)+(0.03*HEIGHT)),1,30); // The last argument is the value
		
		
		// MOTOR TEMP
		display_text((int)(VERT_X+(0.05*WIDTH)),(int)((HEIGHT*0.6667)+(0.03*HEIGHT)),22,"MOTOR"); // TITLE
		display_text((int)(VERT_X+(0.05*WIDTH)),(int)((HEIGHT*0.6667)+(0.13*HEIGHT)),22,"TEMP"); // TITLE
		display_text((int)(VERT_X+(0.05*WIDTH)),(int)((HEIGHT*0.6667)+(0.23*HEIGHT)),22,"(degC)"); // TITLE
		// TO SET A FONT HIGHER THAN 31:
		FT8_cmd_romfont(1,33);
		display_numberRight((int)(WIDTH-(0.03*WIDTH)),(int)((HEIGHT*0.6667)+(0.03*HEIGHT)),1,47); // The last argument is the value
		
		
		
		
		framenum = framenum+1;
		
		
		// test progress bar
		//display_progress(50);
		//display_progress(200,100,40,150,30);
		
		
		
		endFrame();
		
		

		
	}
}
